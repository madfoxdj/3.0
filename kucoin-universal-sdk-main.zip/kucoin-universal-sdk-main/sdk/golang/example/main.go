package main

func main() {
	RestExample()

	WsExample()
}
