
preprocess openapi files